# WARNING:
For Lenovo IdeaPad 320-14IKB only, may not work for your device.
# ELAN Users
Full guide available at:
Github: https://github.com/Ab2774/Lenovo-IdeaPad-320-14-IKB-Hackintosh
Tonymacx86: https://www.tonymacx86.com/threads/guide-lenovo-ideapad-320-14ikb-clover-and-opencore-uefi-hotpatch.293387/


